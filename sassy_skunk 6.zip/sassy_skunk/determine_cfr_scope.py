import re
from langchain.chat_models import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage

def determine_cfr_scope(question: str) -> str:
    """
    Uses an LLM to identify one or more relevant US CFR Title/Part pairs from the user’s question.
    
    The model must return a string in comma-separated format:
      CFR_<title>_PART_<part>, CFR_<title>_PART_<part>, ...
    or a single item in the same format (CFR_40_PART_112), 
    or "CFR_UNKNOWN" if it cannot confidently identify any.

    Examples of valid outputs:
      - CFR_40_PART_112
      - CFR_40_PART_112, CFR_33_PART_154
      - CFR_UNKNOWN

    Returns:
        str: The model's answer. If it doesn't match the pattern, "CFR_UNKNOWN".
    """

    system_prompt = (
        "You are an advanced regulatory assistant with deep knowledge of U.S. CFR (Code of Federal Regulations). "
        "Your task is to identify all relevant CFR Title(s) and Part(s) from the user's question. "
        "Return them in a comma-separated list, with each item in the strict format: CFR_<title>_PART_<part>. "
        "For example: 'CFR_40_PART_112, CFR_33_PART_154'. "
        "If you cannot confidently identify any Title/Part, respond with 'CFR_UNKNOWN'. "
        "Do not provide any additional words or explanation."
    )

    user_prompt = (
        f"The user asked: '{question}'.\n\n"
        "Identify all relevant CFR Title/Part pairs. If multiple, separate them with a comma.\n"
        "If unsure, respond with CFR_UNKNOWN.\n\n"
        "Examples of valid responses:\n"
        "  - CFR_40_PART_112\n"
        "  - CFR_40_PART_112, CFR_33_PART_154\n"
        "  - CFR_UNKNOWN\n\n"
        "Nothing else should be in your response."
    )

    # Call the LLM
    llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.0)
    response = llm([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ])

    raw_answer = response.content.strip()

    # Regex that matches one or more "CFR_<digits>_PART_<digits>"
    # separated by commas (with optional spaces).
    # Example match: "CFR_40_PART_112" or "CFR_40_PART_112, CFR_33_PART_154"
    pattern = re.compile(r'^CFR_\d+_PART_\d+(?:\s*,\s*CFR_\d+_PART_\d+)*$', re.IGNORECASE)

    if pattern.match(raw_answer):
        # Normalize the final answer to uppercase for consistency
        return raw_answer.upper()
    else:
        return "CFR_UNKNOWN"
